/**
 * Package with test classes for framework.
 *
 * @author Eric Dubuis
 *
 */
package ch.bfh.due1.jdt.framework;
