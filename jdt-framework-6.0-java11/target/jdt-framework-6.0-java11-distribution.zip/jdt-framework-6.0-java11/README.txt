JDT Experimental Framework for Simple Graphical Editors
=======================================================

Released on a "AS IS" basis. The framework is based on D. Gruntz's JDraw framework (www.gruntz.ch)
which in turn is based on JHotDraw 6.

Known bugs:
- None.

===
November 24, 2019
Eric Dubuis
